package pages;

import utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;

public class SearchResultsPage {

    private WebDriver driver;
    private WaitUtils waitUtils;

    // ---- Locators via PageFactory ----

    @FindBy(xpath = "//button[@data-testid='filter-dropdown-productDifficultyLevel']")
    private WebElement levelFilterButton;

    @FindBy(xpath = "//button[@data-testid='filter-dropdown-language']")
    private WebElement languageFilterButton;

    @FindBy(xpath = "//*[@id='search-results-frame']/div/div/div/div[1]/aside/div[3]/div/div")
    private WebElement aiOverviewSection;

    // ---- Constructor ----

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
        this.waitUtils = new WaitUtils(driver);
        PageFactory.initElements(driver, this);
    }

    // ---- AI Overview ----

    public boolean isAiOverviewDisplayed() {
        List<WebElement> aiOverview = driver.findElements(
                By.xpath("//*[@id='search-results-frame']/div/div/div/div[1]/aside/div[3]/div/div"));
        return !aiOverview.isEmpty() && aiOverview.get(0).isDisplayed();
    }

    // ---- Level Filter ----

    public void openLevelFilter() {
        waitUtils.waitForClickable(levelFilterButton).click();
    }

    public void selectLevel(String levelName) {
        WebElement label = waitUtils.waitForClickable(
                By.xpath("//label[.//span[text()='" + levelName + "']]"));
        waitUtils.jsClick(label);
    }

    public void clickViewButton() {
        WebElement viewBtn = waitUtils.waitForClickable(
                By.xpath("//button//span[text()='View']"));
        viewBtn.click();
        waitUtils.hardWait(2000);
    }

    // ---- Language Filter ----

    public void openLanguageFilter() {
        waitUtils.waitForClickable(languageFilterButton).click();
    }

    public void selectLanguage(String languageName) {
        WebElement label = waitUtils.waitForClickable(
                By.xpath("//label[.//span[text()='" + languageName + "']]"));
        waitUtils.jsClick(label);
    }

    // ---- Get all available languages (scroll to load all) ----

    public List<String> getAllLanguages() {
        WebElement dropdown = waitUtils.waitForPresence(By.xpath("//div[@role='group']"));
        for (int i = 0; i < 6; i++) {
            waitUtils.jsScrollDown(dropdown);
            waitUtils.hardWait(300);
        }
        List<WebElement> languageElements = waitUtils.waitForAllPresent(
                By.xpath("//div[@class='cds-checkboxAndRadio-labelText']"));
        List<String> languages = new ArrayList<>();
        for (WebElement el : languageElements) {
            String name = el.getText().replaceAll("\\(.*?\\)", "").trim();
            if (!name.isEmpty()) {
                languages.add(name);
            }
        }
        return languages;
    }

    // ---- Get all available levels ----

    public List<String> getAllLevels() {
        List<WebElement> levelElements = waitUtils.waitForAllPresent(
                By.xpath("//div[contains(@class,'cds-checkboxAndRadio-labelText')]"));
        List<String> levels = new ArrayList<>();
        for (WebElement el : levelElements) {
            String name = el.getText().replaceAll("\\(.*?\\)", "").trim();
            if (!name.isEmpty()) {
                levels.add(name);
            }
        }
        return levels;
    }

    public void closeDropdownWithEscape() {
        new Actions(driver).sendKeys(Keys.ESCAPE).perform();
        waitUtils.hardWait(500);
    }

    // ---- Course results ----

    public List<WebElement> getCourseCards() {
        return waitUtils.waitForAllVisible(By.xpath("//li[contains(@class,'cds-9')]"));
    }

    public String getCourseRating(WebElement courseCard) {
        List<WebElement> ratingElements = courseCard.findElements(
                By.xpath(".//span[@class='css-4s48ix']"));
        return ratingElements.isEmpty() ? "No rating found" : ratingElements.get(0).getText();
    }

    public String getCourseDuration(WebElement courseCard) {
        List<WebElement> durationElements = courseCard.findElements(
                By.xpath(".//p[contains(text(),'Weeks') or contains(text(),'Specialization')]"));
        return durationElements.isEmpty() ? "No duration found" : durationElements.get(0).getText();
    }
}
