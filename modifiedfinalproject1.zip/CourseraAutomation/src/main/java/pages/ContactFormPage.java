package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utils.WaitUtils;


public class ContactFormPage {

    WebDriver driver;
    WaitUtils waitUtils;

    // ---- Locators ----

    @FindBy(id = "FirstName")
    WebElement firstNameField;

    @FindBy(id = "LastName")
    WebElement lastNameField;

    @FindBy(id = "Email")
    WebElement emailField;

    @FindBy(id = "Phone")
    WebElement phoneField;

    @FindBy(xpath = "//button[@type='submit' and text()='Submit']")
    WebElement submitButton;

    @FindBy(id = "ValidMsgEmail")
    WebElement emailValidationMessage;

    // ---- Constructor ----

    public ContactFormPage(WebDriver driver) {
        this.driver = driver;
        this.waitUtils = new WaitUtils(driver);
        PageFactory.initElements(driver, this);
    }

    // ---- Actions ----

    public void fillFirstName(String firstName) {
        waitUtils.waitForVisibility(firstNameField).sendKeys(firstName);
    }

    public void fillLastName(String lastName) {
        lastNameField.sendKeys(lastName);
    }

    public void fillEmail(String email) {
        emailField.sendKeys(email);
    }

    public void fillPhone(String phone) {
        phoneField.sendKeys(phone);
    }

    public void fillForm(String firstName, String lastName, String email, String phone) {
        waitUtils.waitForVisibility(By.id("FirstName"));
        fillFirstName(firstName);
        fillLastName(lastName);
        fillEmail(email);
        fillPhone(phone);
    }

    public void clickSubmit() {
        waitUtils.scrollIntoView(submitButton);
        waitUtils.waitForClickable(submitButton).click();
    }

    public String getEmailValidationMessage() {
        WebElement validationMsg = waitUtils.waitForVisibility(emailValidationMessage);
        return validationMsg.getText();
    }

    public boolean isEmailValidationMessageDisplayed() {
        try {
            WebElement msg = waitUtils.waitForVisibility(emailValidationMessage);
            return msg.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
