package pages;

import utils.WaitUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ForBusinessPage {

    private WebDriver driver;
    private WaitUtils waitUtils;

    // ---- Locators ----

    @FindBy(xpath = "//a[@class='cds-149 ContentfulButton cds-button-disableElevation cds-button-primary css-fmh8w5']")
    private WebElement learnMoreButton;

    // ---- Constructor ----

    public ForBusinessPage(WebDriver driver) {
        this.driver = driver;
        this.waitUtils = new WaitUtils(driver);
        PageFactory.initElements(driver, this);
    }

    // ---- Actions ----

    public ContactFormPage clickLearnMore() {
        waitUtils.waitForPresence(
                org.openqa.selenium.By.xpath(
                        "//a[@class='cds-149 ContentfulButton cds-button-disableElevation cds-button-primary css-fmh8w5']"));
        waitUtils.scrollIntoView(learnMoreButton);
        waitUtils.jsClick(learnMoreButton);
        return new ContactFormPage(driver);
    }
}
