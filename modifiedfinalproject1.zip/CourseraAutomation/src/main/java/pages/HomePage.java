package pages;

import utils.WaitUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

    private WebDriver driver;
    private WaitUtils waitUtils;

    // ---- Locators ----

    @FindBy(id = "search-autocomplete-input")
    private WebElement searchBox;

    @FindBy(xpath = "//button[@aria-label='Search']")
    private WebElement searchButton;

    @FindBy(xpath = "//span[normalize-space()='For Businesses']")
    private WebElement forBusinessesMenu;

    // ---- Constructor ----

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.waitUtils = new WaitUtils(driver);
        PageFactory.initElements(driver, this);
    }

    // ---- Actions ----

    public void navigateTo() {
        driver.get("https://www.coursera.org/");
    }

    public SearchResultsPage searchFor(String keyword) {
        waitUtils.waitForVisibility(searchBox).clear();
        searchBox.sendKeys(keyword);
        waitUtils.waitForClickable(searchButton).click();
        return new SearchResultsPage(driver);
    }

    public void clickForBusinesses() {
        waitUtils.waitForClickable(forBusinessesMenu).click();
    }
}
