package utils;

import io.qameta.allure.Allure;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenshotUtils {

    private ScreenshotUtils() {}

    /**
     * Captures a screenshot, saves it to disk, and attaches it to the Allure report.
     *
     * @param driver     the active WebDriver instance
     * @param screenshotName a descriptive name (spaces replaced with underscores)
     * @return the absolute path of the saved file, or empty string on failure
     */
    public static String captureScreenshot(WebDriver driver, String screenshotName) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String safeName = screenshotName.replaceAll("\\s+", "_");
        String screenshotDir = ConfigReader.getProperty("screenshot.dir", "screenshots/");
        String filePath = screenshotDir + safeName + "_" + timestamp + ".png";

        try {
            // Save to disk
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File destFile = new File(filePath);
            destFile.getParentFile().mkdirs();
            FileUtils.copyFile(srcFile, destFile);
            System.out.println("Screenshot saved: " + destFile.getAbsolutePath());

            // Attach to Allure
            byte[] screenshotBytes = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            Allure.addAttachment(safeName, "image/png",
                    new ByteArrayInputStream(screenshotBytes), ".png");

            return destFile.getAbsolutePath();
        } catch (IOException e) {
            System.err.println("Failed to save screenshot: " + e.getMessage());
            return "";
        }
    }
}
