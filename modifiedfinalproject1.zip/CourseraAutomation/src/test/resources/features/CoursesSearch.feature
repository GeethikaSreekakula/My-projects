# Coursera Automation Test Suite
# Tasks: Web Development Search, Language Learning Search, Business Contact Form

Feature: Coursera Course Search and Business Form

  Background:
    Given the browser is opened and Coursera homepage is loaded

  @Task1 @WebDevelopment
  Scenario: Task 1 - Search Web Development courses with Beginner and English filters
    When I search for "Web Development"
    Then I check if AI Overview is displayed for "Task 1"
    When I apply the level filter "Beginner"
    And I apply the language filter "English"
    Then I should see filtered results applied successfully
    And I print the rating and duration of the first 2 courses

  @Task2 @LanguageLearning
  Scenario: Task 2 - Search Language Learning and list all available filters
    When I search for "Language Learning"
    Then I check if AI Overview is displayed for "Task 2"
    When I open the language filter dropdown
    Then I should see all available languages printed
    When I open the level filter dropdown
    Then I should see all available levels printed

  @Task3 @BusinessForm
  Scenario: Task 3 - Submit business contact form with invalid email and capture error
    When I click on For Businesses menu
    And I click Learn More button
    And I fill the contact form with:
      | FirstName | LastName | Email         | Phone      |
      | Geethika    | Sreekakula   | geeth51%$#* | 1234567890 |
    And I click the Submit button
    Then I should see an invalid email validation message
    And a screenshot should be captured showing the error message
