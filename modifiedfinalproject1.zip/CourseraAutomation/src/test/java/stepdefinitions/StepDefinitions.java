package stepdefinitions;

import pages.ContactFormPage;
import pages.ForBusinessPage;
import pages.HomePage;
import pages.SearchResultsPage;
import utils.DriverManager;
import utils.ScreenshotUtils;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import java.util.List;
import java.util.Map;

public class StepDefinitions {

    private WebDriver driver;
    private HomePage homePage;
    private SearchResultsPage searchResultsPage;
    private ForBusinessPage forBusinessPage;
    private ContactFormPage contactFormPage;

    // =================== Background ===================

    @Given("the browser is opened and Coursera homepage is loaded")
    @Step("Open Coursera homepage")
    public void openCourseraHomepage() {
        driver = DriverManager.getDriver();
        homePage = new HomePage(driver);
        homePage.navigateTo();
        System.out.println("Coursera homepage loaded: " + driver.getCurrentUrl());
    }

    // =================== Task 1 & 2 : Search ===================

    @When("I search for {string}")
    @Step("Search for keyword: {0}")
    public void searchForKeyword(String keyword) {
        homePage = new HomePage(driver);
        searchResultsPage = homePage.searchFor(keyword);
        System.out.println("Searched for: " + keyword);
        Allure.parameter("Search Keyword", keyword);
    }

    @Then("I check if AI Overview is displayed for {string}")
    @Step("Check AI Overview visibility")
    public void checkAiOverview(String taskLabel) {
        boolean displayed = searchResultsPage.isAiOverviewDisplayed();
        if (displayed) {
            System.out.println("AI Overview is displayed (" + taskLabel + ")");
            Allure.step("AI Overview is displayed for " + taskLabel);
        } else {
            System.out.println("AI Overview not displayed (" + taskLabel + ")");
            Allure.step("AI Overview NOT displayed for " + taskLabel);
        }
    }

    // =================== Task 1: Filters ===================

    @When("I apply the level filter {string}")
    @Step("Apply level filter: {0}")
    public void applyLevelFilter(String level) {
        searchResultsPage.openLevelFilter();
        searchResultsPage.selectLevel(level);
        searchResultsPage.clickViewButton();
        System.out.println("Level filter applied: " + level);
    }

    @When("I apply the language filter {string}")
    @Step("Apply language filter: {0}")
    public void applyLanguageFilter(String language) {
        searchResultsPage.openLanguageFilter();
        searchResultsPage.selectLanguage(language);
        searchResultsPage.clickViewButton();
        System.out.println("Language filter applied: " + language);
    }

    @Then("I should see filtered results applied successfully")
    @Step("Verify filtered results are displayed")
    public void verifyFilteredResults() {
        List<WebElement> courses = searchResultsPage.getCourseCards();
        Assert.assertFalse(courses.isEmpty(), "No courses found after applying filters!");
        System.out.println("Filters applied successfully. Total courses displayed: " + courses.size());
        Allure.step("Filtered results loaded. Total courses: " + courses.size());
    }

    @Then("I print the rating and duration of the first 2 courses")
    @Step("Print rating and duration of first 2 courses")
    public void printFirst2CoursesDetails() {
        List<WebElement> courses = searchResultsPage.getCourseCards();
        int limit = Math.min(2, courses.size());
        for (int i = 0; i < limit; i++) {
            WebElement course = courses.get(i);
            String rating = searchResultsPage.getCourseRating(course);
            String duration = searchResultsPage.getCourseDuration(course);
            System.out.println("Course " + (i + 1) + " Rating: " + rating);
            System.out.println("Course " + (i + 1) + " Duration: " + duration);
            Allure.step("Course " + (i + 1) + " → Rating: " + rating + " | Duration: " + duration);
        }
    }

    // =================== Task 2: List Filters ===================

    @When("I open the language filter dropdown")
    @Step("Open language filter dropdown")
    public void openLanguageDropdown() {
        searchResultsPage.openLanguageFilter();
    }

    @Then("I should see all available languages printed")
    @Step("Print all available languages")
    public void printAllLanguages() {
        List<String> languages = searchResultsPage.getAllLanguages();
        System.out.println("\nLanguages available:");
        for (String lang : languages) {
            System.out.println(lang);
        }
        System.out.println("\nTotal number of languages: " + languages.size());
        Allure.step("Total languages available: " + languages.size() + " → " + languages);
        searchResultsPage.closeDropdownWithEscape();
    }

    @When("I open the level filter dropdown")
    @Step("Open level filter dropdown")
    public void openLevelDropdown() {
        searchResultsPage.openLevelFilter();
    }

    @Then("I should see all available levels printed")
    @Step("Print all available levels")
    public void printAllLevels() {
        List<String> levels = searchResultsPage.getAllLevels();
        System.out.println("\nLevels available:");
        for (String level : levels) {
            System.out.println(level);
        }
        System.out.println("\nTotal number of levels: " + levels.size());
        Allure.step("Total levels available: " + levels.size() + " → " + levels);
        searchResultsPage.closeDropdownWithEscape();
    }

    // =================== Task 3: Business Form ===================

    @When("I click on For Businesses menu")
    @Step("Click For Businesses menu")
    public void clickForBusinesses() {
        homePage = new HomePage(driver);
        homePage.clickForBusinesses();
        forBusinessPage = new ForBusinessPage(driver);
        System.out.println("Clicked For Businesses");
    }

    @When("I click Learn More button")
    @Step("Click Learn More button")
    public void clickLearnMore() {
        contactFormPage = forBusinessPage.clickLearnMore();
        System.out.println("Clicked Learn More. Current URL: " + driver.getCurrentUrl());
    }

    @When("I fill the contact form with:")
    @Step("Fill contact form")
    public void fillContactForm(DataTable dataTable) {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        Map<String, String> row = data.get(0);

        String firstName = row.get("FirstName");
        String lastName  = row.get("LastName");
        String email     = row.get("Email");
        String phone     = row.get("Phone");

        contactFormPage.fillForm(firstName, lastName, email, phone);
        System.out.println("Form filled → Name: " + firstName + " " + lastName
                + " | Email: " + email + " | Phone: " + phone);
        Allure.parameter("Email Used", email);
    }

    @When("I click the Submit button")
    @Step("Click Submit button")
    public void clickSubmit() {
        contactFormPage.clickSubmit();
        System.out.println("Submit button clicked");
    }

    @Then("I should see an invalid email validation message")
    @Step("Verify invalid email message is shown")
    public void verifyInvalidEmailMessage() {
        Assert.assertTrue(contactFormPage.isEmailValidationMessageDisplayed(),
                "Email validation message was NOT displayed!");
        String message = contactFormPage.getEmailValidationMessage();
        System.out.println("Invalid Email Message: " + message);
        Allure.step("Validation message displayed: " + message);
    }

    @Then("a screenshot should be captured showing the error message")
    @Step("Capture screenshot of error message")
    public void captureErrorScreenshot() {
        String path = ScreenshotUtils.captureScreenshot(driver, "Task3_InvalidEmail_ErrorMessage");
        System.out.println("Screenshot captured at: " + path);
        Assert.assertFalse(path.isEmpty(), "Screenshot was not captured!");
    }
}
