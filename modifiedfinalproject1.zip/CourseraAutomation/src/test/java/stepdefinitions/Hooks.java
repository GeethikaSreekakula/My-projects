package stepdefinitions;

import utils.DriverManager;
import utils.ScreenshotUtils;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.qameta.allure.Allure;
import org.openqa.selenium.WebDriver;

public class Hooks {

    @Before
    public void setUp(Scenario scenario) {
        DriverManager.initDriver();
        Allure.label("feature", scenario.getId());
        System.out.println("=== Starting Scenario: " + scenario.getName() + " ===");
    }

    @After
    public void tearDown(Scenario scenario) {
        WebDriver driver = DriverManager.getDriver();

        if (scenario.isFailed()) {
            // Capture screenshot on failure and attach to Allure
            ScreenshotUtils.captureScreenshot(driver, "FAILED_" + scenario.getName());
            System.out.println("Scenario FAILED: " + scenario.getName());
        } else {
            System.out.println("Scenario PASSED: " + scenario.getName());
        }

        DriverManager.quitDriver();
    }
}
