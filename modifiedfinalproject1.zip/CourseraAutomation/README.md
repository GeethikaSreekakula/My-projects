# Coursera Selenium Automation — Maven + TestNG + Cucumber + Allure

## Project Structure

```
CourseraAutomation/
├── pom.xml
├── testng.xml
├── screenshots/                          ← Auto-created at runtime
├── allure-results/                       ← Auto-created at runtime
└── src/
    ├── main/
    │   ├── java/
    │   │   ├── pages/
    │   │   │   ├── HomePage.java
    │   │   │   ├── SearchResultsPage.java
    │   │   │   ├── ForBusinessPage.java
    │   │   │   └── ContactFormPage.java
    │   │   └── utils/
    │   │       ├── DriverManager.java
    │   │       ├── ConfigReader.java
    │   │       ├── WaitUtils.java
    │   │       └── ScreenshotUtils.java
    │   └── resources/
    │       └── config.properties
    └── test/
        ├── java/
        │   ├── runners/
        │   │   └── TestRunner.java
        │   └── stepdefinitions/
        │       ├── Hooks.java
        │       └── StepDefinitions.java
        └── resources/
            ├── allure.properties
            └── features/
                └── CoursesSearch.feature
```

## Prerequisites

- Java 11+
- Maven 3.8+
- Google Chrome (latest)
- Allure CLI (for viewing reports)

### Install Allure CLI

```bash
# macOS
brew install allure

# Windows (via Scoop)
scoop install allure

# Linux
sudo apt-get install allure
```

## Configuration

Edit `src/main/resources/config.properties` to change settings:

```properties
browser=chrome
headless=false          # set to true for headless mode
explicit.wait=10
page.load.timeout=30
base.url=https://www.coursera.org/
screenshot.dir=screenshots/
```

## How to Run

### Run All Tests
```bash
mvn clean test
```

### Run Specific Task
```bash
# Task 1 only
mvn clean test -Dcucumber.filter.tags="@Task1"

# Task 2 only
mvn clean test -Dcucumber.filter.tags="@Task2"

# Task 3 only
mvn clean test -Dcucumber.filter.tags="@Task3"
```

### Generate and View Allure Report
```bash
# After test run:
mvn allure:report       # generates report in target/site/allure-maven-plugin
mvn allure:serve        # generates + opens in browser automatically
```

## What Each Task Does

| Task | Scenario |
|------|----------|
| Task 1 | Searches "Web Development", checks AI Overview, applies **Beginner** level + **English** language filters, prints rating & duration of first 2 courses |
| Task 2 | Searches "Language Learning", checks AI Overview, opens Language dropdown & lists all languages, opens Level dropdown & lists all levels |
| Task 3 | Navigates to For Businesses → Learn More, fills form with **invalid email**, submits, verifies validation message, **captures screenshot** |

## Screenshot on Task 3

Screenshots are saved to the `screenshots/` folder with a timestamp, e.g.:
```
screenshots/Task3_InvalidEmail_ErrorMessage_20240101_123456.png
```
The screenshot is also **attached to the Allure report** automatically.

## Reports

- **HTML (Cucumber):** `target/cucumber-reports/cucumber.html`
- **JSON (Cucumber):** `target/cucumber-reports/cucumber.json`
- **Allure Results:** `allure-results/`
- **Allure HTML:** run `mvn allure:serve`

## Troubleshooting

- **ChromeDriver mismatch**: WebDriverManager auto-manages the driver; ensure Chrome is installed.
- **Element not found**: Coursera's UI may change; update XPaths in the page objects accordingly.
- **Headless mode issues**: Set `headless=false` in config for debugging.
